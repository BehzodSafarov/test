function scrollPromoSection() {
    const promoSection = document.getElementById('promoSection');
    if (promoSection) {
        promoSection.scrollBy({
            top: 0,
            left: promoSection.offsetWidth, // Scroll one section's width
            behavior: 'smooth'
        });
    }
}
